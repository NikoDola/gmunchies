
import Heading from "../components/ui/Heading"
export default function NotFound(){
  return(
    <section className="section-regular" >
      <Heading  text={"404 not found"}/>
    </section>
  )
}