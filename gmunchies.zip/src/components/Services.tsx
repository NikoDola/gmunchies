import "./Services.css";
import ServiceCard from "./ui/ServiceCard";

type Service = {
  slug: string;
  display: boolean;
  iconSrc: string;
  title: string;
  excerpt: string;
};

type ServicesProps = {
  intro?: {
    eyebrow?: string;
    heading: string;
    body?: string;
  };
  services: Service[];
};

export default function Services({ intro, services }: ServicesProps) {
  const visible = services.filter((s) => s.display);
  return (
    <section className="section-regular">
      <div className="headingWrapper">
        {intro?.eyebrow ? <p className="beforeHeading">{intro.eyebrow}</p> : null}
        <h2 className="h2">{intro?.heading ?? "Services"}</h2>
        {intro?.body ? <p className="afterHeading">{intro.body}</p> : null}
      </div>
      <div className="cardWrapper">
        {visible.map((service) => (
          <ServiceCard
            key={service.slug}
            img={service.iconSrc}
            headline={service.title}
            bodyText={service.excerpt}
            href={`/service/${service.slug}`}
          />
        ))}
      </div>
    </section>
  );
}
