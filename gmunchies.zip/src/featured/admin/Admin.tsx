"use client";

import Dashboard from "./Dashboard";

// Kept for backwards compatibility with older imports.
export default function AdminPage() {
  return <Dashboard />;
}
